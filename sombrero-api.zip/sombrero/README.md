# Sombrero

Svelte 5 · TypeScript · Tailwind CSS 4 · bits-ui

```bash
npm install
npm run dev      # разработка
npm run build    # сборка в dist/
npm run check    # svelte-check
```

## Структура

- `src/lib/parser.ts` — разбор и валидация номеров (разделители, перенос, проверки 5–7 цифр, месяц 01–12, 4 цифры, дубликаты)
- `src/lib/api.ts` — клиент Code Verification API по `swagger.json` (`/check-code`, `/check-status/{order_id}`, `/get-limit`, `/account-info`)
- `src/lib/state.svelte.ts` — состояние: API-ключ, аккаунт, локальная очередь заказов и история, воркер опроса статусов
- `src/lib/config.ts` — адрес API, интервал опроса, параллелизм, размер страницы
- `src/pages/` — Login, Home, History, Billing, Self
- `src/components/` — Header, Footer, Button, Card, Field, Select, CopyButton, Icon, Logo

## Подключение к API

Запросы идут на `API_BASE` (по умолчанию `/api`, как `basePath` в контракте). Авторизация — заголовок `Authorization: <API-ключ>`.

- Dev: создайте `.env.local` с `DEV_API_TARGET=http://<хост API>` — vite проксирует `/api/*` туда (без CORS и mixed content).
- Прод: либо проксируйте `/api` на бэкенд тем же доменом, либо задайте `VITE_API_BASE=https://<хост>/api` при сборке.

| Экран | Эндпоинт |
| --- | --- |
| Вход | `GET /account-info` (401 → неверный ключ) |
| Баланс, цена, кошельки | `GET /account-info` |
| Постановка в очередь | `POST /check-code` на каждый номер → `order_id` |
| Результаты | `GET /check-status/{order_id}`: `valid`→успех, `fail`→неудача, `error`→ошибка (`code_error`), `null`→ещё в работе |
| «В очереди» | `GET /get-limit` → `pending` |

Чего в контракте нет, и потому нет в приложении: регистрации/логина по паролю, Telegram, пополнения, истории платежей. Список отправленных заказов и история проверок хранятся локально в браузере (в API нет эндпоинта истории), отдельно для каждого ключа.

## Маршруты

`#/` проверка · `#/history` · `#/billing` · `#/self` · `#/login` · `#/logout`
