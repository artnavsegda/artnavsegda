import { api, ApiError, type AccountInfo } from './api';
import { CONCURRENCY, POLL_INTERVAL_MS } from './config';
import type { HistoryItem, PendingOrder, Result } from './types';
import type { Parsed } from './parser';

/**
 * Состояние приложения поверх Code Verification API.
 *
 * Что живёт на сервере: баланс, цена, кошельки, заказы и их статусы, счётчик pending.
 * Чего в контракте нет (поэтому хранится локально в браузере, по ключу): список
 * отправленных заказов (order_id → номер) и история завершённых проверок.
 */

const KEY_STORAGE = 'sombrero:api-key';
const DATA_STORAGE = 'sombrero:data:v2:';
const HISTORY_LIMIT = 5000;
const round2 = (n: number) => Math.round(n * 100) / 100;

/** Короткий несекретный идентификатор ключа — чтобы не хранить сам ключ в имени записи. */
function keyId(key: string): string {
  let h = 5381;
  for (let i = 0; i < key.length; i++) h = ((h << 5) + h + key.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}

interface Data {
  pending: PendingOrder[];
  history: HistoryItem[];
}

function readKey(): string | null {
  try {
    return localStorage.getItem(KEY_STORAGE);
  } catch {
    return null;
  }
}

function readData(key: string): Data {
  try {
    const raw = localStorage.getItem(DATA_STORAGE + keyId(key));
    if (raw) {
      const d = JSON.parse(raw);
      return { pending: d.pending ?? [], history: d.history ?? [] };
    }
  } catch {
    /* повреждённые данные */
  }
  return { pending: [], history: [] };
}

/** Выполняет fn над items, не более `limit` одновременно. */
async function pool<T>(items: T[], limit: number, fn: (item: T) => Promise<void>) {
  let i = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length) await fn(items[i++]);
  });
  await Promise.all(workers);
}

export interface EnqueueResult {
  accepted: number;
  failed: { value: string; error: string }[];
  /** Фатальная ошибка (нет сессии / ключ отклонён) — ничего не отправлено или процесс прерван */
  fatal?: string;
}

class Store {
  apiKey = $state<string | null>(readKey());
  account = $state<AccountInfo | null>(null);
  /** pending из /get-limit: сколько проверок ждут на сервере (по всему аккаунту) */
  serverPending = $state<number | null>(null);
  data = $state<Data>(this.apiKey ? readData(this.apiKey) : { pending: [], history: [] });
  /** Последняя ошибка связи при обновлении аккаунта (не 401) */
  offline = $state(false);

  private polling = false;
  private lastAccountSync = 0;

  get authed(): boolean {
    return !!this.apiKey;
  }

  /** Маскированный ключ для отображения: abcd…wxyz */
  get keyMask(): string {
    const k = this.apiKey ?? '';
    return k.length > 10 ? `${k.slice(0, 4)}…${k.slice(-4)}` : '••••';
  }

  get balance(): number {
    return this.account?.balance ?? 0;
  }

  get price(): number {
    return this.account?.price ?? 0;
  }

  get wallets() {
    return this.account?.wallets ?? [];
  }

  get queue(): PendingOrder[] {
    return this.data.pending;
  }

  get history(): HistoryItem[] {
    return this.data.history;
  }

  get stats() {
    return {
      checked: this.history.length,
      queued: this.serverPending ?? this.queue.length,
      affordable: this.price > 0 ? Math.floor(round2(this.balance / this.price) + 1e-9) : 0
    };
  }

  private save() {
    if (!this.apiKey) return;
    try {
      localStorage.setItem(DATA_STORAGE + keyId(this.apiKey), JSON.stringify($state.snapshot(this.data)));
    } catch {
      /* хранилище недоступно */
    }
  }

  // ───── авторизация по API-ключу ─────

  async login(rawKey: string): Promise<Result> {
    const key = rawKey.trim();
    if (!key) return { ok: false, error: 'Введите API-ключ' };
    try {
      const account = await api.accountInfo(key);
      this.apiKey = key;
      this.account = account;
      this.data = readData(key);
      this.offline = false;
      this.lastAccountSync = Date.now();
      try {
        localStorage.setItem(KEY_STORAGE, key);
      } catch {
        /* без сохранения сессии */
      }
      void this.refreshLimit();
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e instanceof ApiError ? e.message : 'Не удалось войти' };
    }
  }

  logout() {
    this.apiKey = null;
    this.account = null;
    this.serverPending = null;
    this.data = { pending: [], history: [] };
    try {
      localStorage.removeItem(KEY_STORAGE);
    } catch {
      /* ignore */
    }
  }

  /** Вызывается при 401 в любом запросе: ключ отозван или недействителен. */
  private handleAuthError(e: unknown): boolean {
    if (e instanceof ApiError && e.unauthorized) {
      this.logout();
      return true;
    }
    return false;
  }

  // ───── аккаунт ─────

  /** GET /account-info: баланс, цена, кошельки */
  async refreshAccount(): Promise<Result> {
    const key = this.apiKey;
    if (!key) return { ok: false, error: 'Нужно войти' };
    try {
      this.account = await api.accountInfo(key);
      this.offline = false;
      this.lastAccountSync = Date.now();
      return { ok: true };
    } catch (e) {
      if (this.handleAuthError(e)) return { ok: false, error: 'Ключ недействителен' };
      this.offline = true;
      return { ok: false, error: e instanceof ApiError ? e.message : 'Ошибка' };
    }
  }

  /** GET /get-limit */
  async refreshLimit() {
    const key = this.apiKey;
    if (!key) return;
    try {
      this.serverPending = (await api.getLimit(key)).pending;
    } catch (e) {
      this.handleAuthError(e);
    }
  }

  // ───── очередь ─────

  /** POST /check-code по каждому номеру. Принятые заказы попадают в локальную очередь. */
  async enqueue(items: Parsed[]): Promise<EnqueueResult> {
    const key = this.apiKey;
    const res: EnqueueResult = { accepted: 0, failed: [] };
    if (!key) return { ...res, fatal: 'Нужно войти в аккаунт' };
    if (!items.length) return { ...res, fatal: 'Нечего добавлять' };

    let aborted = false;
    await pool(items, CONCURRENCY, async (it) => {
      if (aborted) return;
      try {
        const { order_id } = await api.checkCode(key, {
          code_number: it.number,
          month: it.mm,
          last_code: it.tail
        });
        this.data.pending.push({ orderId: String(order_id), value: it.value, createdAt: Date.now() });
        res.accepted++;
      } catch (e) {
        if (this.handleAuthError(e)) {
          aborted = true;
          res.fatal = 'Ключ недействителен — войдите заново';
          return;
        }
        res.failed.push({ value: it.value, error: e instanceof ApiError ? e.message : 'Ошибка' });
      }
    });

    if (this.apiKey) {
      this.save();
      // баланс и счётчик очереди изменились на сервере
      void this.refreshAccount();
      void this.refreshLimit();
    }
    return res;
  }

  /**
   * Один проход воркера: опрашивает GET /check-status/{order_id} по ожидающим заказам.
   * state: valid → success, fail → fail, error → error (+code_error), null → ждём дальше.
   */
  async poll() {
    const key = this.apiKey;
    if (!key || this.polling) return;
    this.polling = true;
    try {
      const batch = this.data.pending.slice(0, 20);
      let changed = false;

      await pool(batch, CONCURRENCY, async (order) => {
        if (this.apiKey !== key) return;
        try {
          const st = await api.checkStatus(key, order.orderId);
          const state = st.state as string | null;
          if (!state || state === 'null') return; // ещё в работе

          const result = state === 'valid' ? 'success' : state === 'fail' ? 'fail' : 'error';
          this.finish(order, {
            result,
            codeError: st.code_error || null,
            zipIsCorrect: st.zip_is_correct ?? null
          });
          changed = true;
        } catch (e) {
          if (this.handleAuthError(e)) return;
          // 400 — заказ не найден/некорректен: не зацикливаемся на нём вечно
          if (e instanceof ApiError && e.status === 400) {
            this.finish(order, { result: 'error', codeError: e.message, zipIsCorrect: null });
            changed = true;
          }
          // сетевые сбои и 5xx — повторим на следующем тике
        }
      });

      if (this.apiKey !== key) return;
      if (changed) this.save();

      const idle = Date.now() - this.lastAccountSync > 30_000;
      if (changed || idle || this.data.pending.length) {
        await Promise.all([this.refreshAccount(), this.refreshLimit()]);
      }
    } finally {
      this.polling = false;
    }
  }

  private finish(
    order: PendingOrder,
    r: Pick<HistoryItem, 'result' | 'codeError' | 'zipIsCorrect'>
  ) {
    const i = this.data.pending.findIndex((p) => p.orderId === order.orderId);
    if (i >= 0) this.data.pending.splice(i, 1);
    this.data.history.unshift({
      id: order.orderId,
      value: order.value,
      checkedAt: Date.now(),
      ...r
    });
    if (this.data.history.length > HISTORY_LIMIT) this.data.history.length = HISTORY_LIMIT;
  }
}

export const store = new Store();

export function startWorker() {
  // подтянуть актуальные данные аккаунта сразу после загрузки страницы
  if (store.authed) {
    void store.refreshAccount();
    void store.refreshLimit();
  }
  setInterval(() => void store.poll(), POLL_INTERVAL_MS);
}
