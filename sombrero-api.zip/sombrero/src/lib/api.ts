import { API_BASE } from './config';

/**
 * Клиент Code Verification API (swagger.json, basePath /api).
 * Авторизация — заголовок Authorization с API-ключом (как в контракте, без префикса).
 */

// ───── типы из контракта ─────

export interface CheckCodeRequest {
  code_number: string;
  /** номер месяца, строка: "10" */
  month: string;
  /** последние четыре цифры */
  last_code: string;
}

export interface CheckCodeResponse {
  order_id: string;
}

export type OrderState = 'error' | 'valid' | 'fail' | 'null';

export interface CheckStatusResponse {
  state: OrderState;
  code_error?: string;
  zip_is_correct?: boolean | null;
}

export interface LimitResponse {
  pending: number;
}

export interface WalletModel {
  name: string;
  network: string;
  currency: string;
  address: string;
}

export interface AccountInfo {
  balance: number;
  price: number;
  wallets: WalletModel[];
}

// ───── ошибки ─────

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string
  ) {
    super(message);
  }
  get unauthorized() {
    return this.status === 401;
  }
}

const STATUS_TEXT: Record<number, string> = {
  400: 'Некорректный запрос',
  401: 'Неверный API-ключ'
};

async function request<T>(apiKey: string, method: 'GET' | 'POST', path: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      method,
      headers: {
        Authorization: apiKey,
        Accept: 'application/json',
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {})
      },
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
  } catch {
    throw new ApiError(0, 'Нет связи с сервером');
  }

  let data: unknown = null;
  try {
    data = await res.json();
  } catch {
    /* пустое или не-JSON тело */
  }

  if (!res.ok) {
    const msg = (data as { message?: string } | null)?.message;
    throw new ApiError(res.status, msg || STATUS_TEXT[res.status] || `Ошибка сервера (${res.status})`);
  }
  return data as T;
}

// ───── методы ─────

export const api = {
  /** POST /check-code — поставить код на проверку, вернёт order_id */
  checkCode: (key: string, req: CheckCodeRequest) => request<CheckCodeResponse>(key, 'POST', '/check-code', req),

  /** GET /check-status/{order_id} */
  checkStatus: (key: string, orderId: string) =>
    request<CheckStatusResponse>(key, 'GET', `/check-status/${encodeURIComponent(orderId)}`),

  /** GET /get-limit — сколько проверок сейчас в ожидании на сервере */
  getLimit: (key: string) => request<LimitResponse>(key, 'GET', '/get-limit'),

  /** GET /account-info — баланс, цена за проверку, кошельки для пополнения */
  accountInfo: (key: string) => request<AccountInfo>(key, 'GET', '/account-info')
};
