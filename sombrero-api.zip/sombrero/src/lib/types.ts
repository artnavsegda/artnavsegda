export type Result = { ok: true } | { ok: false; error: string };

/** Заказ, отправленный в API и ожидающий результата */
export interface PendingOrder {
  orderId: string;
  value: string; // number|mm|tail
  createdAt: number;
}

/** error — ошибка проверки на стороне сервиса (см. codeError) */
export type CheckResult = 'success' | 'fail' | 'error';

export interface HistoryItem {
  id: string; // order_id
  value: string;
  result: CheckResult;
  codeError: string | null;
  zipIsCorrect: boolean | null;
  checkedAt: number;
}
