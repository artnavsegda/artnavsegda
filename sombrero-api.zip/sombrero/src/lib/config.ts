/**
 * Базовый адрес API. По контракту basePath = /api, схема http.
 * По умолчанию — относительный `/api` (прокси на том же домене / vite dev proxy).
 * Чтобы указать сервер напрямую: VITE_API_BASE=http://host/api
 * (при https-фронте и http-API браузер заблокирует запросы — нужен прокси).
 */
export const API_BASE: string = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, '') || '/api';

export const CURRENCY = 'USD';
/** Как часто опрашивать статусы заказов и баланс */
export const POLL_INTERVAL_MS = 3000;
/** Сколько запросов к API выполнять параллельно */
export const CONCURRENCY = 5;
export const PAGE_SIZE = 20;
