<script lang="ts">
  import Card from '../components/Card.svelte';
  import Button from '../components/Button.svelte';
  import Field from '../components/Field.svelte';
  import { store } from '../lib/state.svelte';
  import { go } from '../lib/router.svelte';

  let key = $state('');
  let error = $state('');
  let busy = $state(false);

  async function submit(e: SubmitEvent) {
    e.preventDefault();
    error = '';
    busy = true;
    const r = await store.login(key);
    busy = false;
    if (r.ok) go('/');
    else error = r.error;
  }
</script>

<div class="mx-auto max-w-md pt-6 sm:pt-12">
  <div class="mb-6 text-center">
    <h1 class="text-3xl font-bold tracking-tight text-stone-50">Вход по API-ключу</h1>
    <p class="mt-2 text-stone-400">Введите ключ доступа, чтобы продолжить работу</p>
  </div>

  <Card>
    <form onsubmit={submit} class="space-y-4">
      <Field
        label="API-ключ"
        type="password"
        bind:value={key}
        autocomplete="off"
        mono
        required
        hint="Ключ хранится только в этом браузере и отправляется в заголовке Authorization."
      />
      {#if error}<p class="rounded-lg bg-rose-500/10 px-3 py-2 text-sm text-rose-300">{error}</p>{/if}
      <Button type="submit" full size="lg" disabled={busy || !key.trim()}>{busy ? 'Проверяем…' : 'Войти'}</Button>
    </form>
  </Card>
</div>
