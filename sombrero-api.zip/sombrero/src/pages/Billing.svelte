<script lang="ts">
  import Card from '../components/Card.svelte';
  import Button from '../components/Button.svelte';
  import CopyButton from '../components/CopyButton.svelte';
  import Icon from '../components/Icon.svelte';
  import { store } from '../lib/state.svelte';
  import { money } from '../lib/format';

  let refreshing = $state(false);
  let refreshError = $state('');

  async function refresh() {
    refreshing = true;
    const r = await store.refreshAccount();
    refreshError = r.ok ? '' : r.error;
    refreshing = false;
  }

  const coinColor: Record<string, string> = {
    USDT: 'bg-emerald-500/15 text-emerald-300',
    BTC: 'bg-amber-500/15 text-amber-300',
    ETH: 'bg-indigo-500/15 text-indigo-300'
  };
</script>

<div class="space-y-6">
  <h1 class="text-2xl font-bold tracking-tight text-stone-50">Биллинг</h1>

  <div class="grid gap-6 lg:grid-cols-5">
    <Card class="lg:col-span-2">
      <div class="text-xs tracking-wide text-stone-500 uppercase">Баланс</div>
      <div class="mt-2 font-mono text-4xl font-semibold text-amber-300">{money(store.balance)}</div>
      <div class="mt-1 text-xs text-stone-600">{money(store.price)} за проверку</div>
      <div class="mt-5">
        <Button variant="secondary" size="sm" onclick={refresh} disabled={refreshing}>
          {refreshing ? 'Обновляем…' : 'Обновить баланс'}
        </Button>
        {#if refreshError}<p class="mt-3 text-sm text-rose-300">{refreshError}</p>{/if}
      </div>
    </Card>

    <Card title="Кошельки" description="Адреса для пополнения баланса" class="lg:col-span-3">
      {#if store.wallets.length === 0}
        <div class="flex flex-col items-center gap-4 rounded-xl border border-dashed border-stone-800 px-4 py-8 text-center">
          <span class="flex size-12 items-center justify-center rounded-xl bg-stone-800 text-stone-400">
            <Icon name="wallet" class="size-6" />
          </span>
          <p class="text-sm text-stone-400">Для этого аккаунта кошельки не настроены.</p>
        </div>
      {:else}
        <ul class="space-y-2">
          {#each store.wallets as w (w.address)}
            <li class="flex items-center gap-3 rounded-xl border border-stone-800 bg-stone-950/50 px-3.5 py-3">
              <span class="w-14 shrink-0 rounded-md px-2 py-1 text-center text-xs font-semibold {coinColor[w.currency] ?? 'bg-stone-800 text-stone-300'}">
                {w.currency}
              </span>
              <div class="min-w-0 flex-1">
                <div class="text-xs text-stone-500">{w.name ? `${w.name} · ` : ''}{w.network}</div>
                <div class="truncate font-mono text-sm text-stone-200" title={w.address}>{w.address}</div>
              </div>
              <CopyButton text={w.address} title="Копировать адрес" />
            </li>
          {/each}
        </ul>
      {/if}
    </Card>
  </div>
</div>
