<script lang="ts">
  import Card from '../components/Card.svelte';
  import Button from '../components/Button.svelte';
  import Icon from '../components/Icon.svelte';
  import { store } from '../lib/state.svelte';
  import { go } from '../lib/router.svelte';
  import { money } from '../lib/format';
</script>

{#if store.authed}
  <div class="mx-auto max-w-2xl space-y-6">
    <div class="flex items-center gap-4">
      <span class="flex size-16 items-center justify-center rounded-2xl bg-linear-to-b from-amber-400 to-orange-500 text-stone-950 shadow-lg shadow-orange-500/20">
        <Icon name="user" class="size-7" />
      </span>
      <div>
        <h1 class="text-2xl font-bold tracking-tight text-stone-50">Профиль</h1>
        <p class="text-sm text-stone-500">Доступ по API-ключу</p>
      </div>
    </div>

    <Card title="Аккаунт">
      <dl class="divide-y divide-stone-800/70 text-sm">
        <div class="flex items-center justify-between gap-4 py-3">
          <dt class="text-stone-400">API-ключ</dt>
          <dd class="font-mono text-stone-100">{store.keyMask}</dd>
        </div>
        <div class="flex items-center justify-between gap-4 py-3">
          <dt class="text-stone-400">Баланс</dt>
          <dd class="font-mono text-amber-300">{money(store.balance)}</dd>
        </div>
        <div class="flex items-center justify-between gap-4 py-3">
          <dt class="text-stone-400">Цена проверки</dt>
          <dd class="font-mono text-stone-100">{money(store.price)}</dd>
        </div>
        <div class="flex items-center justify-between gap-4 py-3">
          <dt class="text-stone-400">В очереди на сервере</dt>
          <dd class="font-mono text-stone-100">{store.serverPending ?? '—'}</dd>
        </div>
      </dl>
    </Card>

    <Button variant="secondary" onclick={() => go('/logout')}><Icon name="logout" /> Выйти</Button>
  </div>
{/if}
