import { defineConfig, loadEnv } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  // В dev запросы /api/* проксируются на DEV_API_TARGET (например http://localhost:8000),
  // это же обходит CORS и mixed content.
  const target = env.DEV_API_TARGET;
  return {
    plugins: [tailwindcss(), svelte()],
    server: target ? { proxy: { '/api': { target, changeOrigin: true } } } : undefined
  };
});
