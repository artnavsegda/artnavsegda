<script lang="ts">
  import Icon from '../ui/Icon.svelte';
  import Avatar from '../ui/Avatar.svelte';
  import Toggle from '../ui/Toggle.svelte';
  import Segmented from '../ui/Segmented.svelte';
  import { onMount } from 'svelte';
  import { house } from '../core/house';
  import { theme } from '../client/theme.svelte';
  import { go } from '../client/router.svelte';
  import { people, me, roleName, homeIds, setAvatar, addGuest, removeGuest, addReq, stage, STAGES, RIGHTS, TOPICS, SLOTS, ART,
    setAppearance, setNotif, untilText, type Guest, type Av } from '../client/people.svelte';

  // Профиль жителя: кто я и моя семья, гости с временным доступом, заявки в сервис, оформление и уведомления.
  // Стиль (тренд) выбирает интегратор под заказчика — жителю доступна только тема: авто, светлая, тёмная.
  // Вход — аватар на «Сводке» и знак дома в навигации iPad. Одна страница на все тренды: форма — из токенов.
  const I = $derived(me());
  const home = $derived(homeIds());
  let now = $state(Date.now());
  onMount(() => { const t = setInterval(() => (now = Date.now()), 1000); return () => clearInterval(t); });

  // ——— аватар ———
  let pick = $state<string | null>(null);   // чей аватар меняем
  const pickName = $derived(people.family.find(p => p.id === pick)?.name ?? '');
  function choose(av: Av) { if (pick) setAvatar(pick, av); pick = null; }
  function upload(e: Event) {
    const f = (e.target as HTMLInputElement).files?.[0]; if (!f || !pick) return;
    const id = pick, img = new Image(), url = URL.createObjectURL(f);
    img.onload = () => {
      const c = document.createElement('canvas'), s = 256, k = Math.min(img.width, img.height);
      c.width = c.height = s;
      c.getContext('2d')!.drawImage(img, (img.width - k) / 2, (img.height - k) / 2, k, k, 0, 0, s, s);
      setAvatar(id, { kind: 'photo', src: c.toDataURL('image/jpeg', .85) }); URL.revokeObjectURL(url); pick = null;
    };
    img.src = url;
  }
  const portal = (n: HTMLElement) => { document.body.appendChild(n); return { destroy() { n.remove(); } }; };

  // ——— гости ———
  let inviting = $state(false);
  let gName = $state(''), gPeriod = $state('weekend'), gRights = $state<string[]>(['gate', 'light']);
  let made = $state<Guest | null>(null);
  let copied = $state('');
  function invite() { made = addGuest(gName, gPeriod, gRights); inviting = false; gName = ''; }
  const inviteText = (g: Guest) => `${I.name} приглашает вас в ${house.name}. Код калитки: ${g.code}, ${untilText(g)}. Откройте приложение «Дом» или наберите код на панели у входа.`;
  async function copy(id: string, text: string, el?: HTMLElement) {
    try { await navigator.clipboard.writeText(text); copied = id; }
    catch { if (el) { const r = document.createRange(); r.selectNodeContents(el); getSelection()?.removeAllRanges(); getSelection()?.addRange(r); } copied = id; }
    setTimeout(() => copied === id && (copied = ''), 1800);
  }
  const toggleRight = (id: string) => (gRights = gRights.includes(id) ? gRights.filter(x => x !== id) : [...gRights, id]);

  // ——— сервис ———
  let asking = $state(false);
  let rTopic = $state(TOPICS[0]), rRoom = $state(''), rText = $state(''), rSlot = $state(SLOTS[0]);
  function send() { addReq({ topic: rTopic, room: rRoom, text: rText.trim(), slot: rSlot }); asking = false; rText = ''; rRoom = ''; }
  const roomName = (id: string) => house.rooms.find(r => r.id === id)?.name ?? 'Весь дом';
  const nextTO = $derived.by(() => { const d = new Date(now); d.setDate(d.getDate() + 34); return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' }); });
  const ago = (t: number) => { const m = Math.round((now - t) / 6e4); return m < 1 ? 'только что' : m < 60 ? `${m} мин назад` : m < 1440 ? `${Math.round(m / 60)} ч назад` : new Date(t).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' }); };

  const NOTIF: { id: string; name: string; sub: string; lock?: boolean }[] = [
    { id: 'alarm', name: 'Тревоги и охрана', sub: 'Всегда включено', lock: true },
    { id: 'leak', name: 'Протечка, дым, газ', sub: 'Срочно, со звуком' },
    { id: 'guests', name: 'Гости пришли и ушли', sub: 'Когда открывают калитку по коду' },
    { id: 'service', name: 'Заявки и обслуживание', sub: 'Статус и визит инженера' },
    { id: 'media', name: 'Медиа', sub: 'Кто что включил в зонах' }
  ];
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
</script>

<div class="pr {theme.profile}">
  <div class="bar rise">
    <button class="rd press" aria-label="Назад" onclick={() => (history.length > 1 ? history.back() : go('home'))}><Icon name="back" size={20} /></button>
    <span class="bt">Профиль</span>
    <span class="rd ghost" aria-hidden="true"></span>
  </div>

  <div class="cols">
    <div class="col">
      <!-- кто я -->
      <section class="hero card rise">
        <button class="me press" aria-label="Сменить аватар" onclick={() => (pick = I.id)}>
          <Avatar av={I.av} name={I.name + ' ' + I.last} size={theme.profile === 'tablet' ? 112 : 96} />
          <span class="cam"><Icon name="camera" size={15} /></span>
        </button>
        <div class="who">
          <h1>{I.name} {I.last}</h1>
          <span class="sub">{roleName(I.role)} · {house.name}</span>
          <span class="st" class:in={home.has(I.id)}><i></i>{home.has(I.id) ? 'Дома' : 'Не дома'}</span>
        </div>
        <div class="qa">
          <button class="press" onclick={() => { inviting = true; made = null; scrollTo('guests'); }}><span class="qi"><Icon name="guest" size={20} /></span>Гость</button>
          <button class="press" onclick={() => { asking = true; scrollTo('service'); }}><span class="qi"><Icon name="tool" size={20} /></span>Сервис</button>
          <button class="press" onclick={() => scrollTo('look')}><span class="qi"><Icon name="moon" size={20} /></span>Тема</button>
        </div>
      </section>

      <!-- семья -->
      <section class="rise" style="animation-delay:.04s">
        <h2 class="sh">Семья <span class="num">{people.family.length}</span></h2>
        <div class="fam">
          {#each people.family as p (p.id)}
            <button class="fm card press" onclick={() => (pick = p.id)} aria-label="{p.name}: сменить аватар">
              <Avatar av={p.av} name={p.name + ' ' + p.last} size={52} ring={home.has(p.id)} />
              <b>{p.name}{p.id === I.id ? ' (вы)' : ''}</b>
              <span>{home.has(p.id) ? 'дома' : 'не дома'}</span>
            </button>
          {/each}
        </div>
      </section>

      <!-- оформление -->
      <section id="look" class="rise" style="animation-delay:.08s">
        <h2 class="sh">Тема</h2>
        <div class="card pad">
          <div class="row"><span class="rl"><i>{people.appearance === 'auto' ? 'Тёмная после заката, светлая днём' : people.appearance === 'light' ? 'Всегда светлая' : 'Всегда тёмная'}</i></span></div>
          <Segmented label="Тема" value={people.appearance} options={[{ id: 'auto', name: 'Авто' }, { id: 'light', name: 'Светлая' }, { id: 'dark', name: 'Тёмная' }]} onchange={(v) => setAppearance(v as 'auto')} />
        </div>
      </section>
    </div>

    <div class="col">
      <!-- гости -->
      <section id="guests" class="rise" style="animation-delay:.06s">
        <div class="shr"><h2 class="sh">Гости <span class="num">{people.guests.length}</span></h2>
          {#if !inviting}<button class="add press" onclick={() => { inviting = true; made = null; }}><Icon name="plus" size={16} />Пригласить</button>{/if}</div>

        {#if inviting}
          <form class="card pad form" onsubmit={(e) => { e.preventDefault(); invite(); }}>
            <label class="fld"><span>Кого пригласить</span><input bind:value={gName} placeholder="Имя гостя" autocomplete="off" /></label>
            <div class="fld"><span>На сколько</span>
              <div class="chips">{#each [['today', 'Сегодня'], ['weekend', 'До воскресенья'], ['week', 'Неделя'], ['always', 'Постоянно']] as [id, n]}<button type="button" class="chip" class:on={gPeriod === id} onclick={() => (gPeriod = id)}>{n}</button>{/each}</div></div>
            <div class="fld"><span>Что можно</span>
              <div class="chips">{#each RIGHTS as r}<button type="button" class="chip" class:on={gRights.includes(r.id)} aria-pressed={gRights.includes(r.id)} onclick={() => toggleRight(r.id)}><Icon name={r.icon} size={15} />{r.name}</button>{/each}</div>
              <em class="hint">Охрана, камеры и сценарии гостям не доступны.</em></div>
            <div class="acts"><button type="button" class="btn ghost" onclick={() => (inviting = false)}>Отмена</button><button class="btn pri" disabled={!gRights.length}>Создать приглашение</button></div>
          </form>
        {/if}

        {#if made}
          <div class="card pad made">
            <span class="k">Приглашение готово</span>
            <p id="inv">{inviteText(made)}</p>
            <div class="code num">{made.code}</div>
            <div class="acts">
              <button class="btn ghost" onclick={() => (made = null)}>Готово</button>
              <button class="btn pri" onclick={(e) => made && copy('inv', inviteText(made), (e.currentTarget as HTMLElement).closest('.made')?.querySelector('#inv') as HTMLElement)}><Icon name={copied === 'inv' ? 'ok' : 'copy'} size={16} />{copied === 'inv' ? 'Скопировано' : 'Скопировать текст'}</button>
            </div>
          </div>
        {/if}

        <div class="list">
          {#each people.guests as g (g.id)}
            <div class="gc card">
              <Avatar av={g.av} name={g.name} size={44} />
              <div class="gt">
                <b>{g.name}</b>
                <span class:off={g.until !== null && g.until < now}>{untilText(g)}</span>
                <span class="rights">{#each RIGHTS.filter(r => g.rights.includes(r.id)) as r}<i title={r.name}><Icon name={r.icon} size={14} /></i>{/each}</span>
              </div>
              <div class="gk">
                <button class="pin num press" title="Скопировать код" onclick={() => copy(g.id, g.code)}>{copied === g.id ? 'скопирован' : g.code}</button>
                <button class="rv" onclick={() => removeGuest(g.id)}>Отозвать</button>
              </div>
            </div>
          {:else}<p class="empty">Гостей нет. Пригласите — гость получит код от калитки на нужный срок.</p>{/each}
        </div>
      </section>

      <!-- сервис -->
      <section id="service" class="rise" style="animation-delay:.1s">
        <div class="shr"><h2 class="sh">Обслуживание</h2>
          {#if !asking}<button class="add press" onclick={() => (asking = true)}><Icon name="plus" size={16} />Заявка</button>{/if}</div>

        <div class="to card">
          <span class="ti"><Icon name="tool" size={22} /></span>
          <span class="tt"><b>Плановое ТО · {nextTO}</b><i>Инженер проверит контроллер, датчики и резервное питание. Дату можно сдвинуть.</i></span>
        </div>

        {#if asking}
          <form class="card pad form" onsubmit={(e) => { e.preventDefault(); send(); }}>
            <div class="fld"><span>Что случилось</span>
              <div class="chips">{#each TOPICS as t}<button type="button" class="chip" class:on={rTopic === t} onclick={() => (rTopic = t)}>{t}</button>{/each}</div></div>
            <label class="fld"><span>Где</span>
              <select bind:value={rRoom}><option value="">Весь дом</option>{#each house.rooms as r}<option value={r.id}>{r.name}</option>{/each}</select></label>
            <label class="fld"><span>Подробности</span><textarea bind:value={rText} rows="3" placeholder="Например: штора в спальне закрывается не до конца"></textarea></label>
            <div class="fld"><span>Когда удобно</span>
              <div class="chips">{#each SLOTS as t}<button type="button" class="chip" class:on={rSlot === t} onclick={() => (rSlot = t)}>{t}</button>{/each}</div></div>
            <div class="acts"><button type="button" class="btn ghost" onclick={() => (asking = false)}>Отмена</button><button class="btn pri">Отправить</button></div>
          </form>
        {/if}

        <div class="list">
          {#each people.reqs as r (r.id)}
            {@const k = stage(r, now)}
            <div class="rq card">
              <div class="rh"><b>{r.topic}</b><span class="num">{ago(r.created)}</span></div>
              <span class="rm">{roomName(r.room)} · {r.slot.toLowerCase()}</span>
              {#if r.text}<p>{r.text}</p>{/if}
              <ol class="steps" style="--k:{k / (STAGES.length - 1)}">
                {#each STAGES as s, i}<li class:done={i <= k} class:cur={i === k}><i></i><span>{s.name}</span></li>{/each}
              </ol>
              {#if k >= 2 && r.eng}<span class="eng"><Icon name="person" size={14} />Инженер {r.eng}{k < 3 ? ` · ${r.slot.toLowerCase()}` : ''}</span>{/if}
            </div>
          {/each}
        </div>
      </section>

      <!-- уведомления -->
      <section class="rise" style="animation-delay:.14s">
        <h2 class="sh">Уведомления</h2>
        <div class="card nt">
          {#each NOTIF as n (n.id)}
            <div class="nr"><span class="rl"><b>{n.name}</b><i>{n.sub}</i></span>
              {#if n.lock}<span class="lk"><Icon name="lock" size={16} /></span>{:else}<Toggle on={people.notif[n.id]} label={n.name} onchange={(v) => setNotif(n.id, v)} />{/if}</div>
          {/each}
        </div>
        <p class="foot">{house.name} · контроллер на связи · приложение 0.9</p>
      </section>
    </div>
  </div>
</div>

{#if pick}
  <div class="ov {theme.profile}" use:portal role="presentation">
    <button class="bd" aria-label="Закрыть" onclick={() => (pick = null)}></button>
    <div class="sheet" role="dialog" aria-modal="true" aria-label="Аватар">
      <div class="shh"><b>Аватар · {pickName}</b><button class="rd press" aria-label="Закрыть" onclick={() => (pick = null)}><Icon name="x" size={18} /></button></div>
      <div class="avs">
        {#each ART as _, n}<button class="press" aria-label="Рисунок {n + 1}" onclick={() => choose({ kind: 'art', n })}><Avatar av={{ kind: 'art', n }} name={pickName} size={64} /></button>{/each}
        <button class="press" aria-label="Инициалы" onclick={() => choose({ kind: 'ini' })}><Avatar av={{ kind: 'ini' }} name={pickName} size={64} /></button>
      </div>
      <label class="btn pri up"><Icon name="camera" size={18} />Загрузить фото<input type="file" accept="image/*" onchange={upload} hidden /></label>
    </div>
  </div>
{/if}

<style>
  .pr { display: flex; flex-direction: column; gap: 14px; padding: max(14px, env(safe-area-inset-top, 0px)) max(16px, env(safe-area-inset-right, 0px)) 28px max(16px, env(safe-area-inset-left, 0px)); }
  .tablet.pr { padding: 24px 32px 48px; max-width: 1240px; }
  .bar { display: flex; align-items: center; justify-content: space-between; }
  .bt { font: 500 15px var(--font-ui); color: var(--sub); }
  .tablet .bar { justify-content: flex-start; gap: 14px; }
  .rd { width: 42px; height: 42px; border-radius: 50%; border: 1px solid var(--border); background: var(--surface); color: var(--text); display: grid; place-items: center; }
  .rd.ghost { visibility: hidden; }
  .cols { display: flex; flex-direction: column; gap: 22px; }
  .tablet .cols { display: grid; grid-template-columns: minmax(0, 5fr) minmax(0, 6fr); gap: 28px; align-items: start; }
  .col { display: flex; flex-direction: column; gap: 22px; min-width: 0; }
  section { display: flex; flex-direction: column; gap: 10px; scroll-margin-top: 16px; }
  .sh { margin: 0; font: 600 15px var(--font-ui); letter-spacing: 0; }
  .sh .num { color: var(--muted); font-weight: 400; margin-left: 4px; }
  .shr { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
  .card { border-radius: var(--r-xl, 26px); border: 1px solid var(--border); background: var(--surface); }
  .pad { padding: 16px; }

  /* кто я */
  .hero { display: flex; flex-direction: column; align-items: center; text-align: center; gap: 14px; padding: 26px 16px 16px; position: relative; overflow: hidden; isolation: isolate; }
  .hero::before { content: ''; position: absolute; inset: -40% -20% 45%; z-index: -1; background: radial-gradient(closest-side, var(--accent-soft), transparent); }
  .me { position: relative; border: 0; background: none; padding: 0; border-radius: 50%; }
  .me :global(.av) { box-shadow: 0 0 0 4px var(--bg), 0 16px 40px rgba(0,0,0,.28); }
  .cam { position: absolute; right: 0; bottom: 2px; width: 32px; height: 32px; border-radius: 50%; background: var(--accent); color: var(--on-accent); display: grid; place-items: center; box-shadow: 0 0 0 3px var(--bg); }
  .who { display: flex; flex-direction: column; align-items: center; gap: 4px; }
  h1 { margin: 0; font: var(--display-weight, 300) 30px/1.1 var(--font-display); letter-spacing: var(--display-tracking, -.02em); }
  .tablet h1 { font-size: 36px; }
  .sub { font-size: 13px; color: var(--muted); }
  .st { margin-top: 6px; display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 11px; border-radius: 999px; background: var(--surface-2); font-size: 12px; color: var(--sub); }
  .st i { width: 7px; height: 7px; border-radius: 50%; background: var(--muted); }
  .st.in i { background: var(--ok); box-shadow: 0 0 0 3px color-mix(in srgb, var(--ok) 25%, transparent); }
  .qa { align-self: stretch; display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; margin-top: 6px; padding-top: 14px; border-top: 1px solid var(--border); }
  .qa button { border: 0; background: none; display: flex; flex-direction: column; align-items: center; gap: 7px; color: var(--sub); font: 500 12px var(--font-ui); }
  .qi { width: 52px; height: 52px; border-radius: 50%; display: grid; place-items: center; background: var(--surface-2); color: var(--text); }

  /* семья */
  .fam { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }
  .fm { display: grid; grid-template-columns: auto minmax(0, 1fr); grid-template-rows: auto auto; column-gap: 12px; align-items: center; padding: 12px; text-align: left; color: var(--text); border-radius: var(--r-lg, 20px); }
  .fm :global(.av) { grid-row: 1 / 3; }
  .fm b { font-weight: 600; font-size: 14px; align-self: end; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .fm span { font-size: 12px; color: var(--muted); align-self: start; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

  /* формы */
  .add { display: inline-flex; align-items: center; gap: 5px; height: 34px; padding: 0 13px; border-radius: 999px; border: 1px solid var(--border-strong); background: var(--surface); color: var(--text); font: 500 13px var(--font-ui); }
  .form { display: flex; flex-direction: column; gap: 14px; }
  .fld { display: flex; flex-direction: column; gap: 7px; }
  .fld > span { font-size: 12px; color: var(--muted); }
  .fld input, .fld textarea, .fld select { font: 400 16px var(--font-ui); color: var(--text); background: var(--surface-2); border: 1px solid var(--border); border-radius: var(--r-md, 14px); padding: 11px 13px; outline: none; width: 100%; box-sizing: border-box; resize: vertical; }
  .fld select { appearance: none; background-image: linear-gradient(45deg, transparent 50%, currentColor 50%), linear-gradient(135deg, currentColor 50%, transparent 50%); background-position: calc(100% - 18px) 50%, calc(100% - 13px) 50%; background-size: 5px 5px; background-repeat: no-repeat; }
  .fld input:focus, .fld textarea:focus, .fld select:focus { border-color: var(--accent-border); }
  .chips { display: flex; flex-wrap: wrap; gap: 6px; }
  .chips .chip { display: inline-flex; align-items: center; gap: 6px; height: 34px; font-size: 13px; }
  .hint { font-size: 12px; color: var(--muted); font-style: normal; }
  .acts { display: flex; justify-content: flex-end; gap: 8px; }
  .btn { display: inline-flex; align-items: center; justify-content: center; gap: 7px; height: 44px; padding: 0 18px; border-radius: 999px; font: 600 14px var(--font-ui); border: 1px solid var(--border-strong); background: var(--surface); color: var(--text); cursor: pointer; }
  .btn.pri { background: var(--accent); color: var(--on-accent); border-color: transparent; }
  .btn:disabled { opacity: .4; }

  /* гости */
  .made { display: flex; flex-direction: column; gap: 10px; border-color: var(--accent-border); background: var(--accent-soft); }
  .made .k { font-size: 12px; color: var(--accent-text); font-weight: 600; }
  .made p { margin: 0; font-size: 14px; line-height: 1.45; user-select: text; }
  .code { font-size: 34px; letter-spacing: .08em; }
  .list { display: flex; flex-direction: column; gap: 8px; }
  .gc { display: flex; align-items: center; gap: 12px; padding: 12px 12px 12px 14px; border-radius: var(--r-lg, 20px); }
  .gt { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
  .gt b { font-size: 14px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .gt > span { font-size: 12px; color: var(--muted); }
  .gt .off { color: var(--danger, #d0655a); }
  .rights { display: flex; gap: 4px; margin-top: 3px; }
  .rights i { width: 24px; height: 24px; border-radius: 50%; display: grid; place-items: center; background: var(--surface-2); color: var(--sub); }
  .gk { display: flex; flex-direction: column; align-items: flex-end; gap: 6px; }
  .pin { height: 30px; padding: 0 10px; border-radius: 999px; border: 1px dashed var(--border-strong); background: none; color: var(--text); font-size: 13px; letter-spacing: .06em; white-space: nowrap; }
  .rv { border: 0; background: none; padding: 0; font-size: 12px; color: var(--muted); text-decoration: underline; text-underline-offset: 3px; }
  .empty { margin: 0; font-size: 13px; color: var(--muted); }

  /* сервис */
  .to { display: flex; gap: 12px; align-items: flex-start; padding: 14px; border-radius: var(--r-lg, 20px); }
  .ti { flex: none; width: 44px; height: 44px; border-radius: 14px; display: grid; place-items: center; background: var(--accent-soft); color: var(--accent-text); }
  .tt { display: flex; flex-direction: column; gap: 3px; }
  .tt b { font-size: 14px; font-weight: 600; }
  .tt i { font-style: normal; font-size: 12.5px; color: var(--muted); line-height: 1.4; }
  .rq { display: flex; flex-direction: column; gap: 6px; padding: 14px; border-radius: var(--r-lg, 20px); }
  .rh { display: flex; justify-content: space-between; gap: 10px; }
  .rh b { font-size: 14px; font-weight: 600; }
  .rh span { font-size: 12px; color: var(--muted); white-space: nowrap; }
  .rm { font-size: 12px; color: var(--muted); }
  .rq p { margin: 0; font-size: 13.5px; line-height: 1.4; color: var(--sub); }
  .steps { position: relative; list-style: none; margin: 8px 0 0; padding: 0; display: grid; grid-template-columns: repeat(4, 1fr); }
  .steps::before, .steps::after { content: ''; position: absolute; top: 5px; left: 12.5%; height: 2px; border-radius: 1px; background: var(--border-strong); right: 12.5%; }
  .steps::after { background: var(--accent); right: auto; width: calc(75% * var(--k)); transition: width .8s var(--ease-out); }
  .steps li { position: relative; z-index: 1; display: flex; flex-direction: column; align-items: center; gap: 6px; text-align: center; }
  .steps i { width: 12px; height: 12px; border-radius: 50%; background: var(--surface-solid, var(--bg)); border: 2px solid var(--border-strong); box-sizing: border-box; transition: background-color .4s, border-color .4s; }
  .steps .done i { background: var(--accent); border-color: var(--accent); }
  .steps .cur i { box-shadow: 0 0 0 4px var(--accent-soft); }
  .steps span { font-size: 10.5px; color: var(--muted); line-height: 1.2; }
  .steps .done span { color: var(--sub); }
  .eng { display: inline-flex; align-items: center; gap: 6px; font-size: 12.5px; color: var(--accent-text); margin-top: 4px; }

  /* оформление и уведомления */
  #look .card { display: flex; flex-direction: column; gap: 12px; }
  .row { display: flex; align-items: center; justify-content: space-between; }
  .rl { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
  .rl b { font-size: 14px; font-weight: 600; }
  .rl i { font-style: normal; font-size: 12px; color: var(--muted); }
  .nt { display: flex; flex-direction: column; padding: 4px 16px; }
  .nr { display: flex; align-items: center; justify-content: space-between; gap: 12px; min-height: 60px; border-bottom: 1px solid var(--border); }
  .nr:last-child { border-bottom: 0; }
  .lk { color: var(--muted); padding-right: 8px; }
  .foot { margin: 6px 0 0; text-align: center; font-size: 12px; color: var(--muted); }

  /* выбор аватара */
  .ov { position: fixed; inset: 0; z-index: 70; display: flex; align-items: flex-end; justify-content: center; }
  .ov.tablet { align-items: center; }
  .bd { position: absolute; inset: 0; border: 0; padding: 0; background: rgba(8,8,10,.5); }
  .sheet { position: relative; width: 100%; max-width: 460px; box-sizing: border-box; padding: 18px 18px max(22px, env(safe-area-inset-bottom, 0px)); display: flex; flex-direction: column; gap: 16px;
    background-color: var(--surface-solid, var(--bg)); background-image: var(--bg-img); color: var(--text); border: 1px solid var(--border); border-radius: 28px 28px 0 0; box-shadow: 0 -20px 60px rgba(0,0,0,.35); animation: up .4s var(--ease-out) both; font-family: var(--font-ui); }
  .tablet .sheet { border-radius: 28px; }
  @keyframes up { from { transform: translateY(30px); opacity: 0; } }
  .shh { display: flex; align-items: center; justify-content: space-between; }
  .shh b { font: 600 16px var(--font-ui); }
  .avs { display: grid; grid-template-columns: repeat(auto-fill, minmax(64px, 1fr)); gap: 12px; justify-items: center; }
  .avs button { border: 0; background: none; padding: 0; border-radius: 50%; }
  .up { cursor: pointer; }

  /* тренды: форма поверх токенов */
  :global([data-trend="minimal"]) .pr .card, :global([data-trend="minimal"]) .pr .btn, :global([data-trend="minimal"]) .pr .add, 
  :global([data-trend="minimal"]) .pr .fld input, :global([data-trend="minimal"]) .pr .fld textarea, :global([data-trend="minimal"]) .pr .fld select { border-radius: 0; }
  :global([data-trend="minimal"]) .pr .sh { font-size: 11px; text-transform: uppercase; letter-spacing: .14em; color: var(--muted); }
  :global([data-trend="brutal"]) .pr .card { border: 2px solid var(--border); border-radius: 0; box-shadow: var(--hard); }
  :global([data-trend="brutal"]) .pr .btn, :global([data-trend="brutal"]) .pr .add,  :global([data-trend="brutal"]) .pr .qi, :global([data-trend="brutal"]) .pr .rd,
  :global([data-trend="brutal"]) .pr .pin, :global([data-trend="brutal"]) .pr .ti, :global([data-trend="brutal"]) .pr .fld input, :global([data-trend="brutal"]) .pr .fld textarea, :global([data-trend="brutal"]) .pr .fld select { border-radius: 0; border-width: 2px; }
  :global([data-trend="brutal"]) .pr .sh, :global([data-trend="brutal"]) .pr h1 { text-transform: uppercase; }
  :global([data-trend="brutal"]) .sheet { border-radius: 0; border: 2px solid var(--border); }
  :global([data-trend="nordic"]) .pr .hero { background-image: var(--bg-img); }
</style>
