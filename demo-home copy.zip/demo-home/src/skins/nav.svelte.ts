import { theme } from '../client/theme.svelte';
import { routes, type RouteName } from '../client/router.svelte';
import { home } from '../client/store.svelte';
import { fmtT, pluralPeople } from '../client/derive.svelte';
import { stats } from '../client/domscene.svelte';

// Общее для всех навигаций: какие разделы, какой активен, что про каждый сказать одной строкой.
export const navItems = () => {
  const list = routes.filter(r => (theme.profile === 'tablet' ? r.tablet : r.phone));
  // в минимализме первая вкладка — «Дом», «Сводка» за ней
  if (theme.t.id === 'minimal') { const i = list.findIndex(r => r.name === 'plan'); if (i > 0) list.unshift(...list.splice(i, 1)); }
  return list;
};
/** стартовая страница: у минимализма — «Дом», у остальных — «Сводка» */
export const startRoute = (): RouteName => (theme.t.id === 'minimal' ? 'plan' : 'home');
export const isActive = (current: string, n: string) => n === current || routes.find(r => r.name === current)?.parent === n;
export const armed = () => home.s?.security.mode !== 'disarmed';
export const hideOn = (current: string) => current === 'ar' || current === 'lamp' || current === 'photo';
export const roman = (n: number) => ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'][n] ?? String(n);
export const navIcons: Record<string, string> = { home: 'room', plan: 'plan', overview: 'grid', house: 'house', media: 'media', climate: 'climate', security: 'shield' };

/** одна строка о состоянии раздела — для оглавлений «Минимализма» и «Галереи» */
export function routeStatus(name: RouteName): string {
  const s = home.s; if (!s) return '';
  const x = stats();
  switch (name) {
    case 'plan': return [x.people ? `дома ${pluralPeople(x.people)}` : 'дома никого', `свет в ${x.lit} комн.`].join(' · ');
    case 'home': return 'сцены, подсказки, избранное';
    case 'media': return x.playing ? `играет в ${x.playing} комн.` : 'тишина';
    case 'climate': return x.inside !== undefined ? `внутри ${fmtT(x.inside)}°, снаружи ${fmtT(s.outside)}°` : '';
    case 'security': return x.sec === 'disarmed' ? 'охрана снята' : `охрана: ${x.secName}`;
    case 'house': return 'фасад, участок, ворота';
    default: return '';
  }
}
