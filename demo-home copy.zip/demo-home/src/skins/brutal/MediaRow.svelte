<script lang="ts">
  import { S, ui, engine, act } from '../../media/state.svelte';
  import { mc, step } from '../../media/mc.svelte';
  import { go } from '../../client/router.svelte';

  // Брутальный мини-плеер в списке приборов: вместо [ВКЛ/ВЫКЛ] — что играет, ASCII-время и три квадратные кнопки.
  // Тап по имени или строке — открыть сам источник (полный плеер зоны), если тихо — медиацентр.
  let { zone, name }: { zone: string; name: string } = $props();
  const st = $derived(S.zone[zone]);
  const src = $derived(st?.session ? S.src[st.session.source] : undefined);
  const c = $derived(src?.content);
  const node = $derived(st?.session ? engine.nodes[st.session.source] : undefined);
  const playing = $derived(!!src?.playing);
  const pct = $derived(st?.plan ? st.plan.elapsed / st.plan.total : c?.dur ? (c.pos ?? 0) / c.dur : 0);
  const N = 16;
  const tape = $derived('■'.repeat(Math.round(pct * N)) + '□'.repeat(N - Math.round(pct * N)));
  const mmss = (s = 0) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  const open = () => { ui.zone = zone; if (st?.session || st?.plan) { mc.full = zone; mc.tab = ''; } else go('media'); };
</script>

<li class="mr" class:on={playing}>
  <div class="l1">
    <button class="nm" onclick={open}>{name}</button>
    <span class="tag">{st?.plan ? 'ВКЛЮЧАЮ…' : playing ? '● ЭФИР' : c ? 'ПАУЗА' : 'ТИХО'}</span>
  </div>
  <button class="now" onclick={open}>
    {#if st?.plan}<b>{st.plan.title}</b>
    {:else if c}<b>{c.title}</b><i>{c.sub}{node ? ` / ${node.name}` : ''}</i>
    {:else}<b>НИЧЕГО НЕ ИГРАЕТ</b><i>ВЫБРАТЬ →</i>{/if}
  </button>
  {#if src && !st?.plan}
    <div class="l3">
      <span class="tp num" aria-hidden="true">{tape}</span>
      <span class="tm num">{mmss(c?.pos)}</span>
      <span class="ctl">
        <button aria-label="Назад" onclick={() => step(zone, -1)}>|◀</button>
        <button class="pp" aria-label={playing ? 'Пауза' : 'Играть'} onclick={() => act(() => engine.toggle(zone))}>{playing ? '▮▮' : '▶'}</button>
        <button aria-label="Дальше" onclick={() => step(zone, 1)}>▶|</button>
      </span>
    </div>
  {/if}
</li>

<style>
  .mr { display: flex; flex-direction: column; gap: 6px; padding: 10px 0; border-bottom: 2px solid var(--border); }
  .l1 { display: flex; align-items: center; gap: 8px; }
  .nm { flex: 1; min-width: 0; border: 0; background: none; padding: 0; color: var(--link); text-align: left; font: 600 13px var(--font-ui); text-transform: uppercase; text-decoration: underline; text-underline-offset: 3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .tag { flex: none; font: 700 11px var(--font-ui); padding: 2px 6px; border: 2px solid var(--border); }
  .on .tag { background: var(--accent); color: var(--on-accent); border-color: var(--accent); }
  .now { display: flex; flex-direction: column; align-items: flex-start; gap: 2px; border: 0; background: none; padding: 0; color: var(--text); text-align: left; min-width: 0; }
  .now b { font: 900 22px/1 var(--font-display); text-transform: uppercase; letter-spacing: -.03em; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .now i { font: 600 11px var(--font-ui); font-style: normal; text-transform: uppercase; color: var(--muted); max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .l3 { display: flex; align-items: center; gap: 8px; min-width: 0; }
  .tp { flex: 1; min-width: 0; overflow: hidden; font-size: 12px; letter-spacing: -.05em; white-space: nowrap; }
  .tm { flex: none; font: 600 11px var(--font-ui); }
  .ctl { flex: none; display: flex; }
  .ctl button { width: 44px; height: 34px; border: 2px solid var(--border); margin-left: -2px; background: var(--surface); color: var(--text); font: 700 12px var(--font-ui); letter-spacing: -.1em; }
  .ctl .pp { background: var(--text); color: var(--bg); }
  .ctl button:active { background: var(--accent); color: var(--on-accent); }
</style>
