import { projectId, house } from '../core/house';
import { home } from './store.svelte';

// Люди дома и личные настройки: кто я, семья, гости с временным доступом, заявки в сервис,
// оформление (светлая/тёмная/авто) и уведомления. Живёт в браузере — на сервере это будет учётная запись жителя.
// Хранилище может быть недоступно (песочница) — тогда всё работает до перезагрузки.

export type Av = { kind: 'art'; n: number } | { kind: 'photo'; src: string } | { kind: 'ini' };
export type Person = { id: string; name: string; last: string; role: 'owner' | 'family' | 'child'; av: Av };
export type Guest = { id: string; name: string; until: number | null; rights: string[]; code: string; av: Av; created: number };
export type Req = { id: string; topic: string; room: string; text: string; slot: string; created: number; eng?: string };
/** рисованные аватары — плоская иллюстрация без лица: фон, кожа, волосы (причёска), одежда, борода, очки */
export type Art = { bg: string; skin: string; hair: string; style: 'long' | 'short' | 'bun' | 'braid' | 'tousled'; cloth: string; beard?: boolean; glasses?: boolean };
export const ART: Art[] = [
  { bg: '#E9D5BF', skin: '#E8B896', hair: '#6B3A22', style: 'long', cloth: '#F2E6D6' },
  { bg: '#C9D6CC', skin: '#C98E6B', hair: '#2A1D16', style: 'long', cloth: '#5E7A68' },
  { bg: '#EBCFC2', skin: '#EDC2A3', hair: '#D9D4CE', style: 'bun', cloth: '#B4593A', glasses: true },
  { bg: '#CDD6E2', skin: '#E0A983', hair: '#2B2522', style: 'short', cloth: '#3A3F47', beard: true },
  { bg: '#DCD3B0', skin: '#8D5A3E', hair: '#1E1612', style: 'tousled', cloth: '#8C7C3E' },
  { bg: '#DCCFE6', skin: '#F0C4A4', hair: '#8B5A35', style: 'braid', cloth: '#9DB39A' },
  { bg: '#F2DDB0', skin: '#F1C7A5', hair: '#D9A54A', style: 'tousled', cloth: '#2F3E5C' },
  { bg: '#C7DDD8', skin: '#B07455', hair: '#3A2418', style: 'short', cloth: '#D9824A', glasses: true }
];
export type Appearance = 'auto' | 'light' | 'dark';

export const RIGHTS: { id: string; name: string; icon: string }[] = [
  { id: 'gate', name: 'Калитка и дверь', icon: 'key' },
  { id: 'light', name: 'Свет и климат', icon: 'bulb' },
  { id: 'media', name: 'Медиа', icon: 'media' },
  { id: 'guestroom', name: 'Гостевая', icon: 'door' }
];
export const TOPICS = ['Не работает устройство', 'Настроить сценарий', 'Добавить устройство', 'Другое'];
export const SLOTS = ['Сегодня вечером', 'Завтра утром', 'Завтра днём', 'Когда удобно инженеру'];
/** стадии заявки: время (с) от создания, когда стадия наступает — демо-ускорение */
export const STAGES: { t: number; name: string }[] = [
  { t: 0, name: 'Отправлена' }, { t: 4, name: 'Принята' }, { t: 12, name: 'Инженер назначен' }, { t: 3600 * 20, name: 'Выполнена' }
];

const KEY = `dd.people.${projectId}`;
const day = 864e5;
const defaults = () => ({
  me: 'anna',
  family: [
    { id: 'anna', name: 'Анна', last: 'Лебедева', role: 'owner', av: { kind: 'art', n: 0 } },
    { id: 'mikhail', name: 'Михаил', last: 'Лебедев', role: 'family', av: { kind: 'art', n: 3 } },
    { id: 'sonya', name: 'Соня', last: 'Лебедева', role: 'child', av: { kind: 'art', n: 5 } },
    { id: 'lev', name: 'Лев', last: 'Лебедев', role: 'child', av: { kind: 'art', n: 6 } }
  ] as Person[],
  guests: [
    { id: 'g1', name: 'Няня Ольга', until: null, rights: ['gate', 'light'], code: '304 518', av: { kind: 'ini' }, created: Date.now() - 40 * day },
    { id: 'g2', name: 'Тётя Вера', until: Date.now() + 2 * day, rights: ['gate', 'light', 'guestroom'], code: '771 206', av: { kind: 'art', n: 2 }, created: Date.now() - day }
  ] as Guest[],
  reqs: [
    { id: 'r1', topic: 'Не работает устройство', room: '', text: 'Римская штора в спальне закрывается не до конца.', slot: 'Завтра утром', created: Date.now() - 3 * day, eng: 'Сергей' }
  ] as Req[],
  appearance: 'auto' as Appearance,
  notif: { alarm: true, leak: true, guests: true, service: true, media: false } as Record<string, boolean>
});
type Data = ReturnType<typeof defaults>;
function load(): Data {
  const d = defaults();
  try { const v = JSON.parse(localStorage.getItem(KEY) ?? 'null'); if (v && Array.isArray(v.family)) return { ...d, ...v, notif: { ...d.notif, ...v.notif } }; } catch { /* песочница */ }
  return d;
}
export const people = $state(load());
export function save() { try { localStorage.setItem(KEY, JSON.stringify(people)); } catch { /* песочница или фото слишком большое */ } }

export const me = () => people.family.find(p => p.id === people.me) ?? people.family[0];
export const roleName = (r: Person['role']) => ({ owner: 'Хозяйка дома', family: 'Семья', child: 'Ребёнок' })[r];

/** кто из семьи сейчас дома: первые N по числу людей в доме (в симуляторе люди безымянны) */
export function homeIds(): Set<string> {
  const n = home.s ? Object.values(home.s.presence).reduce((a, b) => a + b, 0) : 0;
  const order = [people.me, ...people.family.map(p => p.id).filter(id => id !== people.me)];
  return new Set(order.slice(0, Math.min(n, order.length)));
}

/** первое открытие за сессию — «С возвращением домой» */
let first = true;
try { first = !sessionStorage.getItem('dd.welcomed'); sessionStorage.setItem('dd.welcomed', '1'); } catch { /* песочница */ }
const t0 = Date.now();
/** «С возвращением домой» — первые три минуты после открытия, потом обычное приветствие по времени суток */
export const hello = (greet: string, now: Date) => (first && +now - t0 < 180000 ? 'С возвращением домой' : greet);

export function setAvatar(id: string, av: Av) {
  const p = people.family.find(x => x.id === id) ?? people.guests.find(x => x.id === id);
  if (p) { p.av = av; save(); }
}

const code = () => { const n = String(Math.floor(100000 + Math.random() * 900000)); return n.slice(0, 3) + ' ' + n.slice(3); };
export function addGuest(name: string, period: string, rights: string[]): Guest {
  const end = new Date(); end.setHours(23, 59, 0, 0);
  const until = period === 'today' ? +end : period === 'weekend' ? +end + ((7 - end.getDay()) % 7) * day : period === 'week' ? +end + 6 * day : null;
  const g: Guest = { id: 'g' + Date.now(), name: name.trim() || 'Гость', until, rights, code: code(), av: { kind: 'ini' }, created: Date.now() };
  people.guests = [g, ...people.guests]; save(); return g;
}
export function removeGuest(id: string) { people.guests = people.guests.filter(g => g.id !== id); save(); }

const ENG = ['Сергей', 'Андрей', 'Илья'];
export function addReq(r: Omit<Req, 'id' | 'created'>) {
  people.reqs = [{ ...r, id: 'r' + Date.now(), created: Date.now(), eng: ENG[people.reqs.length % ENG.length] }, ...people.reqs]; save();
}
export const stage = (r: Req, now: number) => { let i = 0; STAGES.forEach((s, k) => { if ((now - r.created) / 1000 >= s.t) i = k; }); return i; };

export function setAppearance(a: Appearance) { people.appearance = a; save(); }
export function setNotif(k: string, v: boolean) { people.notif[k] = v; save(); }

export const untilText = (g: Guest) => {
  if (g.until === null) return 'постоянный доступ';
  const d = new Date(g.until), now = new Date();
  if (g.until < +now) return 'доступ истёк';
  const same = d.toDateString() === now.toDateString();
  return 'до ' + (same ? 'конца дня' : d.toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'short' }));
};
export const houseName = () => house.name;
