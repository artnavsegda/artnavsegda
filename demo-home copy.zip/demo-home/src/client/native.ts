import { Capacitor, SystemBars, SystemBarsStyle } from '@capacitor/core';
import { Haptics, ImpactStyle } from '@capacitor/haptics';

// Мостик к телефону в сборке Capacitor. В браузере и в артефакте всё молча ничего не делает.
export const isNative = Capacitor.isNativePlatform();

/** лёгкий тактильный отклик — переключатели, вкладки */
export function tap(strong = false) {
  if (isNative) Haptics.impact({ style: strong ? ImpactStyle.Medium : ImpactStyle.Light }).catch(() => {});
}

/** цвет значков статус-бара под тему интерфейса */
export function systemBars(mode: 'day' | 'night') {
  if (isNative) SystemBars.setStyle({ style: mode === 'night' ? SystemBarsStyle.Dark : SystemBarsStyle.Light }).catch(() => {});
}
