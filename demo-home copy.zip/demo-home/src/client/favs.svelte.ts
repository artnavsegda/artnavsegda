import { house, projectId, deviceById } from '../core/house';

// Избранное сводки — личное, у каждого объекта своё. Стартует с house.favorites.home (то, что заложил интегратор),
// дальше живёт в браузере. Хранилище может быть недоступно (песочница) — тогда список просто не переживёт перезагрузку.
const KEY = `dd.favs.${projectId}`;
function load(): string[] {
  try { const v = JSON.parse(localStorage.getItem(KEY) ?? 'null'); if (Array.isArray(v)) return v.filter((id: string) => deviceById[id]); } catch { /* песочница */ }
  return [...house.favorites.home];
}
export const favs = $state({ ids: load() });
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(favs.ids)); } catch { /* песочница */ } };
export const isFav = (id: string) => favs.ids.includes(id);
export function toggleFav(id: string) {
  favs.ids = isFav(id) ? favs.ids.filter(x => x !== id) : [...favs.ids, id];
  save();
}
