<script lang="ts">
  import { ART, type Av } from '../client/people.svelte';
  // Аватар жителя: фото, рисованный портрет из набора (плоская иллюстрация без черт лица) или инициалы.
  // ring — кольцо присутствия «дома».
  let { av, name, size = 44, ring = false }: { av: Av; name: string; size?: number; ring?: boolean } = $props();
  const ini = $derived(name.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase());
  const a = $derived(ART[(av.kind === 'art' ? av.n : name.charCodeAt(0) + name.length) % ART.length]);
</script>

<span class="av" class:ring style="--s:{size}px" aria-hidden="true">
  {#if av.kind === 'photo'}
    <img src={av.src} alt="" draggable="false" />
  {:else if av.kind === 'art'}
    <svg viewBox="0 0 80 80" width={size} height={size}>
      <rect width="80" height="80" fill={a.bg} />
      <circle cx="62" cy="16" r="22" fill="#fff" opacity=".18" />
      <!-- волосы сзади -->
      {#if a.style === 'long'}<path d="M23 38C21 19 31 13 40 13s19 6 17 25l3 24c-6 3-11 0-11-6H31c0 6-5 9-11 6z" fill={a.hair} />
      {:else if a.style === 'braid'}<path d="M25 34c-1-14 7-20 15-20s16 6 15 20z" fill={a.hair} />{#each [0, 1, 2, 3] as i}<circle cx={56 + i * .6} cy={42 + i * 7} r={4.6 - i * .5} fill={a.hair} />{/each}
      {:else if a.style === 'bun'}<circle cx="40" cy="13" r="8" fill={a.hair} />{/if}
      <!-- плечи и шея -->
      <path d="M8 80c2-17 15-25 32-25s30 8 32 25z" fill={a.cloth} />
      <path d="M34 44h12v11c0 3-12 3-12 0z" fill={a.skin} />
      <path d="M34 50c3 3 9 3 12 0v-4H34z" fill="#000" opacity=".12" />
      <!-- голова -->
      <ellipse cx="40" cy="33" rx="13" ry="15" fill={a.skin} />
      <ellipse cx="27.5" cy="35" rx="2.4" ry="3.6" fill={a.skin} />
      <ellipse cx="52.5" cy="35" rx="2.4" ry="3.6" fill={a.skin} />
      {#if a.beard}<path d="M27.5 34c0 12 6 16 12.5 16s12.5-4 12.5-16c-3 5-7 6-12.5 6s-9.5-1-12.5-6z" fill={a.hair} />{/if}
      <!-- волосы спереди -->
      {#if a.style === 'long' || a.style === 'braid'}<path d="M27 32c0-11 6-17 14-17 7 0 12 5 12 13-6-4-12-6-17-4-4 2-7 5-9 8z" fill={a.hair} />
      {:else if a.style === 'short' || a.style === 'bun'}<path d="M26.5 31c-1-11 6-17 14-17s14.5 6 13 17c-2-5-6-8-13-8s-11 3-14 8z" fill={a.hair} />
      {:else}<path d="M26 31c-2-6 0-11 4-13-1-3 3-6 6-4 2-3 7-3 9 0 3-2 7 1 6 4 4 2 5 7 3 13-2-4-5-6-9-6-2 2-5 3-8 2-3-1-6 0-8 2-1 1-2 1-3 2z" fill={a.hair} />{/if}
      {#if a.glasses}<g fill="none" stroke="#2A221C" stroke-width="1.6" opacity=".85"><circle cx="34.5" cy="34" r="4.2" /><circle cx="45.5" cy="34" r="4.2" /><path d="M38.7 34h2.6" /></g>{/if}
      <ellipse cx="34" cy="40" rx="2.6" ry="1.6" fill="#E06F5C" opacity=".18" />
      <ellipse cx="46" cy="40" rx="2.6" ry="1.6" fill="#E06F5C" opacity=".18" />
    </svg>
  {:else}
    <span class="ini" style="background:linear-gradient(140deg,{a.bg},{a.cloth}); color:#1E1712">{ini}</span>
  {/if}
</span>

<style>
  .av { position: relative; flex: none; width: var(--s); height: var(--s); border-radius: 50%; overflow: hidden; display: inline-grid; place-items: center; background: var(--surface-2); isolation: isolate; }
  .av.ring { box-shadow: 0 0 0 2px var(--bg), 0 0 0 4px var(--ok); }
  img, svg { width: 100%; height: 100%; object-fit: cover; display: block; }
  .ini { width: 100%; height: 100%; display: grid; place-items: center; font: 600 calc(var(--s) * .38) var(--font-display); letter-spacing: -.02em; }
  :global([data-trend="brutal"]) .av { border-radius: 0; filter: grayscale(1) contrast(1.3); }
</style>
