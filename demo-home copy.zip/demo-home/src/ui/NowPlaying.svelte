<script lang="ts">
  import MediaTile from './MediaTile.svelte';
  import { activeZones } from '../media/mc.svelte';
  // «Сейчас играет» на сводке: по мини-плееру на каждую зону, где что-то идёт. Несколько зон — несколько плиток.
  let { delay = 0 }: { delay?: number } = $props();
  const zones = $derived(activeZones());
</script>

{#if zones.length}
  <div class="np" class:one={zones.length === 1}>
    {#each zones as z, i (z)}<MediaTile zone={z} delay={delay + i * .04} />{/each}
  </div>
{/if}

<style>
  .np { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
  .np.one { grid-template-columns: minmax(0, 1fr); }
  :global(.tablet) .np { grid-template-columns: repeat(3, minmax(0, 1fr)); }
</style>
