<script lang="ts">
  import Icon from './Icon.svelte';
  import Art from '../media/Art.svelte';
  import { S, ui, engine, act } from '../media/state.svelte';
  import { mc, step } from '../media/mc.svelte';
  import { go } from '../client/router.svelte';

  // Плитка-мини-медиацентр вместо «колонки с переключателем»: обложка размыта на фоне, сверху зона,
  // посередине обложка, название и исполнитель, внизу полоса времени и «назад · пауза · дальше».
  // Тап — открыть сам источник: полноэкранный плеер этой зоны; если тихо — медиацентр с выбранной зоной.
  let { zone, delay = 0 }: { zone: string; delay?: number } = $props();
  const z = $derived(engine.zones[zone]);
  const st = $derived(S.zone[zone]);
  const src = $derived(st?.session ? S.src[st.session.source] : undefined);
  const c = $derived(src?.content);
  const node = $derived(st?.session ? engine.nodes[st.session.source] : undefined);
  const playing = $derived(!!src?.playing);
  const pct = $derived(st?.plan ? st.plan.elapsed / st.plan.total : c?.dur ? (c.pos ?? 0) / c.dur : 0);
  const open = () => { ui.zone = zone; if (st?.session || st?.plan) { mc.full = zone; mc.tab = ''; } else go('media'); };
  const stop = (e: Event) => e.stopPropagation();
</script>

<article class="tile card mt rise" class:live={!!c} class:playing style="animation-delay:{delay}s">
  <div class="bg" aria-hidden="true">{#if c}<Art art={c.art} kind={c.kind} title="" size="fill" />{/if}</div>
  <button class="hit" aria-label="{z?.name}: {c ? `${c.title}, открыть плеер` : 'открыть медиацентр'}" onclick={open}></button>
  <div class="hd">
    <span class="zn">{z?.name ?? 'Медиа'}</span>
    {#if playing}<span class="eq" aria-hidden="true"><i></i><i></i><i></i></span>{:else if node}<span class="src">{node.name}</span>{/if}
  </div>
  {#if st?.plan}
    <div class="mid"><span class="ph"><Icon name="media" size={20} /></span><span class="tt"><b>{st.plan.title}</b><i>{Math.max(0, Math.ceil(st.plan.total - st.plan.elapsed))} с</i></span></div>
  {:else if c}
    <div class="mid">
      <span class="cv"><Art art={c.art} kind={c.kind} title={c.title} size="s" /></span>
      <span class="tt"><b>{c.title}</b><i>{c.sub}</i></span>
    </div>
  {:else}
    <div class="mid"><span class="ph"><Icon name={z?.display ? 'media' : 'speaker'} size={20} /></span><span class="tt"><b>Тишина</b><i>Выбрать, что включить</i></span></div>
  {/if}
  <div class="ft">
    <span class="pr"><span style="width:{pct * 100}%"></span></span>
    {#if src && !st?.plan}
      <button class="ic" aria-label="Назад" onclick={(e) => { stop(e); step(zone, -1); }}><Icon name="back" size={16} /></button>
      <button class="pp" aria-label={playing ? 'Пауза' : 'Играть'} onclick={(e) => { stop(e); act(() => engine.toggle(zone)); }}><Icon name={playing ? 'pause' : 'play'} size={16} /></button>
      <button class="ic" aria-label="Дальше" onclick={(e) => { stop(e); step(zone, 1); }}><Icon name="next" size={16} /></button>
    {/if}
  </div>
</article>

<style>
  .mt { position: relative; height: 150px; border-radius: var(--r-xl, 26px); border: 1px solid var(--border); background: var(--surface); overflow: hidden; isolation: isolate; display: flex; flex-direction: column; justify-content: space-between; padding: 12px 12px 12px 14px; box-sizing: border-box; color: var(--text); }
  .bg { position: absolute; inset: -30%; z-index: 0; opacity: 0; filter: blur(26px) saturate(1.3); transition: opacity 1s; pointer-events: none; }
  .bg :global(.art) { aspect-ratio: auto; height: 100%; border-radius: 0; }
  .live .bg { opacity: .55; }
  .live::after { content: ""; position: absolute; inset: 0; z-index: 0; background: linear-gradient(180deg, transparent 20%, color-mix(in srgb, var(--surface-solid) 70%, transparent)); pointer-events: none; }
  .hit { position: absolute; inset: 0; z-index: 2; border: 0; background: none; cursor: pointer; border-radius: inherit; }
  .hd, .mid, .ft { position: relative; z-index: 3; pointer-events: none; }
  .hd { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
  .zn { font-weight: 600; font-size: 13.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .src { font-size: 11.5px; color: var(--muted); white-space: nowrap; }
  .eq { display: flex; align-items: flex-end; gap: 2px; height: 12px; }
  .eq i { width: 3px; border-radius: 1px; background: var(--accent); animation: eq 1s ease-in-out infinite; }
  .eq i:nth-child(2) { animation-delay: -.35s; } .eq i:nth-child(3) { animation-delay: -.7s; }
  @keyframes eq { 0%, 100% { height: 30%; } 50% { height: 100%; } }
  .mid { display: flex; align-items: center; gap: 10px; min-width: 0; }
  .cv { width: 46px; flex: none; border-radius: 10px; overflow: hidden; box-shadow: 0 6px 16px rgba(0,0,0,.35); }
  .cv :global(.art) { aspect-ratio: 1; }
  .ph { width: 46px; height: 46px; flex: none; border-radius: 12px; display: grid; place-items: center; background: var(--surface-2); color: var(--muted); }
  .tt { display: flex; flex-direction: column; min-width: 0; }
  .tt b { font-weight: 600; font-size: 13.5px; line-height: 1.2; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .tt i { font-style: normal; font-size: 11.5px; color: var(--muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .ft { display: flex; align-items: center; gap: 6px; }
  .pr { flex: 1; height: 3px; border-radius: 2px; background: var(--border-strong); overflow: hidden; }
  .pr span { display: block; height: 100%; background: var(--text); transition: width .25s linear; }
  .ic, .pp { pointer-events: auto; position: relative; z-index: 4; width: 30px; height: 30px; border-radius: 50%; border: 0; display: grid; place-items: center; flex: none; }
  .ic { background: none; color: var(--text); }
  .pp { background: var(--text); color: var(--bg); }
  :global([data-trend="minimal"]) .mt, :global([data-trend="minimal"]) .cv, :global([data-trend="minimal"]) .ph { border-radius: 0; }
  @media (prefers-reduced-motion: reduce) { .eq i { animation: none; height: 60%; } }
</style>
