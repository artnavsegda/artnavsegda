<script lang="ts">
  import Icon from './Icon.svelte';
  import DeviceRow from './DeviceRow.svelte';
  import { find } from '../client/find.svelte';
  import { route } from '../client/router.svelte';
  import { house, floors, roomById } from '../core/house';
  import { home } from '../client/store.svelte';
  import { photoFor, photoDim } from '../client/rooms';
  import { roomLight } from '../client/derive.svelte';
  import { theme } from '../client/theme.svelte';
  import { go } from '../client/router.svelte';
  import { fmtT, pluralPeople } from '../client/derive.svelte';
  import { roomsOnFloor, roomStatus, hereRoom, search, multiFloor, floorName } from '../client/nav.svelte';

  // Лист «Комнаты и поиск» поверх «Дома»: все помещения по этажам живыми фото (свет на фото следует за домом)
  // и поиск — самый короткий путь в большом доме: «детская телевизор» находит устройство за два нажатия.
  let q = $state('');
  const res = $derived(search(q));
  const here = $derived(hereRoom());
  const read = (k: string) => { try { return sessionStorage.getItem(k) ?? ''; } catch { return ''; } };
  q = read('rooms.q');
  $effect(() => { try { sessionStorage.setItem('rooms.q', q); } catch { /* нет хранилища */ } });
  const close = () => (find.open = false);
  const to = (id: string) => { close(); go('room', id); };
  // любой переход (в т.ч. «назад») закрывает лист
  let seen = `${route.name}|${route.arg}`;
  $effect(() => { const k = `${route.name}|${route.arg}`; if (k !== seen) { seen = k; close(); } });
  const focus = (el: HTMLInputElement) => { if (theme.profile === 'tablet' || !q) setTimeout(() => el.focus({ preventScroll: true }), 260); };
</script>

<svelte:window onkeydown={(e) => e.key === 'Escape' && close()} />
<div class="ov {theme.profile}" role="presentation">
<button class="bd" aria-label="Закрыть" onclick={close}></button>
<div class="scr sheet" role="dialog" aria-modal="true" aria-label="Комнаты и поиск">
  <header>
    <div class="ht">
      <h2 class="h">Комнаты</h2>
      <span class="label">{house.rooms.length} помещений{multiFloor ? ` · ${floors.length} этажа` : ''}</span>
      <button class="x press" aria-label="Закрыть" onclick={close}><Icon name="x" size={18} /></button>
    </div>
    <label class="search">
      <Icon name="search" size={20} />
      <input type="search" placeholder={theme.profile === 'phone' ? 'Комната или устройство' : 'Комната или устройство: «детская телевизор»'} bind:value={q} aria-label="Поиск по дому" use:focus />
      {#if q}<button class="clr" aria-label="Очистить" onclick={() => (q = '')}><Icon name="x" size={16} /></button>{/if}
    </label>
  </header>

  {#if q.trim()}
    <section class="results rise" aria-live="polite">
      {#if res.rooms.length}
        <h2 class="sh">Комнаты</h2>
        <div class="list">
          {#each res.rooms as r}
            <button class="rr press" onclick={() => to(r.id)}><b>{r.name}</b><span class="label">{floorName(r.id)}</span><Icon name="next" size={18} /></button>
          {/each}
        </div>
      {/if}
      {#if res.devices.length}
        <h2 class="sh">Устройства</h2>
        <div class="devs">
          {#each res.devices as d (d.id)}
            <div class="hit">
              <button class="where" onclick={() => to(d.room)}>{roomById[d.room].name}{multiFloor ? ` · ${floorName(d.room)}` : ''}<Icon name="next" size={12} /></button>
              <DeviceRow id={d.id} />
            </div>
          {/each}
        </div>
      {/if}
      {#if !res.rooms.length && !res.devices.length}<p class="label">Ничего не нашлось. Попробуйте «свет», «шторы», название комнаты.</p>{/if}
    </section>
  {:else}
    {#each floors as f, fi}
      <section class="floor rise" style="animation-delay:{0.04 + fi * 0.04}s" aria-label={f.name}>
        {#if multiFloor}<h2 class="sh">{f.name}<span class="num">&nbsp;· {roomsOnFloor(f.id).length}</span></h2>{/if}
        <div class="grid">
          {#each roomsOnFloor(f.id) as r (r.id)}
            {@const s = roomStatus(r.id)}
            {@const ph = photoFor(r.id, !!home.s?.night)}
            <button class="rc press" class:photo={!!ph} class:here={r.id === here} onclick={() => to(r.id)}>
              {#if ph}
                <img src={house.photos[ph].src} alt="" draggable="false" loading="lazy" />
                <span class="dim" style="opacity:{home.s ? photoDim(ph, roomLight(r.id), home.s) : 0}"></span>
              {:else}
                <span class="glow" style="opacity:{roomLight(r.id)}"></span>
              {/if}
              {#if r.id === here}<span class="tag">вы здесь</span>{/if}
              <span class="ic">
                {#if s.people}<span class="pp" title={pluralPeople(s.people)}><i></i>{s.people}</span>{:else if s.here}<span class="pp"><i></i></span>{/if}
                {#if s.media}<span><Icon name={s.media.caps.includes('speaker') ? 'speaker' : 'media'} size={14} /></span>{/if}
              </span>
              <span class="rt">
                <b>{r.name}</b>
                <span class="num">{[s.temp !== undefined ? fmtT(s.temp) + '°' : '', s.lights ? `свет · ${s.lights}` : 'свет выкл.'].filter(Boolean).join(' · ')}</span>
              </span>
            </button>
          {/each}
        </div>
      </section>
    {/each}
  {/if}
</div>
</div>

<style>
  .ov { position: fixed; inset: 0; z-index: 60; display: flex; align-items: flex-end; justify-content: center; }
  .tablet.ov { align-items: center; padding: 28px; }
  .bd { position: absolute; inset: 0; border: 0; padding: 0; background: rgba(8,8,10,.5); animation: fade .3s both; }
  .sheet { position: relative; width: 100%; height: calc(100% - max(28px, env(safe-area-inset-top, 0px))); overflow: auto; overscroll-behavior: contain; box-sizing: border-box;
    background-color: var(--surface-solid, var(--bg)); background-image: var(--bg-img); border: 1px solid var(--border); border-radius: var(--r-xl, 28px) var(--r-xl, 28px) 0 0; box-shadow: 0 -20px 60px rgba(0,0,0,.35); animation: up .42s var(--ease-out) both; }
  .tablet .sheet { max-width: 1000px; height: 100%; border-radius: var(--r-xl, 28px); }
  @keyframes up { from { transform: translateY(40px); opacity: 0; } to { transform: none; opacity: 1; } }
  @keyframes fade { from { opacity: 0; } }
  @media (prefers-reduced-motion: reduce) { .sheet, .bd { animation: none; } }
  .scr { display: flex; flex-direction: column; gap: 18px; padding: 22px 24px 28px; }
  .phone .scr { padding: 18px max(16px, env(safe-area-inset-right, 0px)) max(24px, env(safe-area-inset-bottom, 0px)) max(16px, env(safe-area-inset-left, 0px)); gap: 16px; }
  header { display: flex; flex-direction: column; gap: 14px; position: sticky; top: -22px; z-index: 2; margin: -22px -24px 0; padding: 22px 24px 12px; background-color: var(--surface-solid, var(--bg)); background-image: var(--bg-img); }
  .phone header { top: -18px; margin: -18px -16px 0; padding: 18px 16px 12px; }
  .ht { display: flex; align-items: baseline; gap: 12px; }
  .h { margin: 0; font: var(--display-weight, 300) clamp(26px, 3.4vw, 36px)/1.05 var(--font-display); letter-spacing: -.02em; }
  .ht .label { flex: 1; min-width: 0; }
  .x { flex: none; align-self: center; width: 40px; height: 40px; border-radius: 50%; border: 1px solid var(--border); background: var(--surface); color: var(--sub); display: grid; place-items: center; }
  .search { display: flex; align-items: center; gap: 10px; height: 52px; padding: 0 14px; border-radius: var(--r-pill); background: var(--surface); border: 1px solid var(--border-strong); color: var(--muted); }
  .search input { flex: 1; min-width: 0; border: 0; background: none; font: inherit; font-size: 16px; color: var(--text); outline: none; }
  .search input::-webkit-search-cancel-button { display: none; }
  .clr { border: 0; background: var(--surface-2); width: 28px; height: 28px; border-radius: 50%; display: grid; place-items: center; color: var(--sub); }
  .sh { font-size: 15px; font-family: var(--font-ui); font-weight: 600; letter-spacing: 0; margin-bottom: 10px; }
  .sh .num { color: var(--muted); font-weight: 400; }
  .floor { display: flex; flex-direction: column; }
  .list { display: grid; gap: 8px; }
  .tablet .list { grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); }
  .rr { display: flex; align-items: center; gap: 10px; min-height: 60px; padding: 0 12px 0 16px; border-radius: var(--r-md); border: 1px solid var(--border); background: var(--surface); text-align: left; color: var(--text); }
  .tag { font-size: 11px; padding: 2px 7px; border-radius: 999px; background: var(--accent); color: var(--on-accent); white-space: nowrap; }
  .pp i { width: 8px; height: 8px; border-radius: 50%; background: var(--cool); display: inline-block; }
  .grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
  .tablet .grid { grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 14px; }
  .rc { position: relative; aspect-ratio: 4 / 3.4; border-radius: var(--r-lg); overflow: hidden; border: 1px solid var(--border); background: var(--surface); padding: 0; text-align: left; color: var(--text); isolation: isolate; }
  .rc img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; z-index: -3; }
  .rc .dim { position: absolute; inset: 0; background: #06070a; z-index: -2; transition: opacity 1.6s var(--ease-light); }
  .rc.photo::after { content: ''; position: absolute; inset: 35% 0 0; background: linear-gradient(transparent, rgba(0,0,0,.7)); z-index: -1; }
  .rc.here { box-shadow: 0 0 0 2px var(--accent); border-color: transparent; }
  .rc .glow { position: absolute; left: -30%; top: -30%; width: 160%; height: 120%; background: radial-gradient(closest-side, color-mix(in srgb, var(--glow, #ffb464) 45%, transparent), transparent); transition: opacity 1.6s var(--ease-light); z-index: -1; }
  .rc .tag { position: absolute; top: 10px; left: 10px; }
  .rc .ic { position: absolute; top: 10px; right: 10px; display: flex; gap: 6px; }
  .rc .ic > span { display: inline-flex; align-items: center; gap: 4px; height: 24px; padding: 0 8px; border-radius: 999px; font-size: 12px; background: var(--surface); color: var(--sub); }
  .photo .ic > span { background: rgba(0,0,0,.45); color: #fff; -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); }
  .rt { position: absolute; left: 12px; right: 12px; bottom: 11px; display: flex; flex-direction: column; gap: 2px; }
  .photo .rt { color: #fff; }
  .rt b { font-weight: 600; font-size: 16px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .rt span { font-size: 12px; opacity: .82; }
  .results { display: flex; flex-direction: column; gap: 8px; }
  .devs { display: grid; gap: 12px; }
  .tablet .devs { grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); }
  .hit { display: flex; flex-direction: column; gap: 4px; }
  .where { align-self: flex-start; border: 0; background: none; padding: 0 2px; font-size: 12px; color: var(--muted); display: inline-flex; align-items: center; gap: 2px; }
  .rr b { font-weight: 500; font-size: 16px; }
  .rr .label { margin-left: auto; }
  :global([data-trend="minimal"]) .search, :global([data-trend="minimal"]) .rr, :global([data-trend="minimal"]) .tag, :global([data-trend="minimal"]) .rc, :global([data-trend="minimal"]) .sheet { border-radius: 0; }
  :global([data-trend="minimal"]) .sh { font-size: 11px; text-transform: uppercase; letter-spacing: .14em; color: var(--muted); }
</style>
