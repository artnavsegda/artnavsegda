<script lang="ts">
  import Events from './Events.svelte';
  import { home } from '../client/store.svelte';
  import { theme } from '../client/theme.svelte';

  // «Дом сейчас» — то, что было ценного в старом «Обзоре»: потребление с живым графиком и лента событий.
  // Вёрстка нейтральная, на токенах: каждый тренд красит её сам (.card, рамки, шрифты).
  let { delay = 0, plain = false }: { delay?: number; plain?: boolean } = $props();
  let series = $state<number[]>([]);
  $effect(() => {
    series = Array.from({ length: 48 }, (_, i) => (home.s?.power ?? 600) * (0.86 + 0.14 * Math.sin(i / 4) + 0.05 * Math.sin(i * 1.7)));
    const t = setInterval(() => { series = [...series.slice(-47), home.s?.power ?? 0]; }, 1000);
    return () => clearInterval(t);
  });
  const kw = $derived(((home.s?.power ?? 0) / 1000).toLocaleString('ru', { minimumFractionDigits: 1, maximumFractionDigits: 1 }));
  const path = $derived.by(() => {
    if (series.length < 2) return { l: '', a: '' };
    const mx = Math.max(...series) * 1.08, mn = Math.min(...series) * 0.85;
    const pts = series.map((v, i) => [(i / (series.length - 1)) * 100, 34 - ((v - mn) / (mx - mn || 1)) * 30]);
    const l = pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`).join(' ');
    return { l, a: `${l} L100 36 L0 36 Z` };
  });
</script>

<div class="vt {theme.profile}" class:plain>
  <section class="pw card rise" style="animation-delay:{delay}s">
    <div class="hd"><span class="label">Потребление</span><span class="live"><i></i>сейчас</span></div>
    <div class="v"><b class="num">{kw}</b><span>кВт</span></div>
    <svg viewBox="0 0 100 36" preserveAspectRatio="none" aria-hidden="true"><path class="a" d={path.a} /><path class="l" d={path.l} /></svg>
  </section>
  <section class="ev card rise" style="animation-delay:{delay + .04}s">
    <div class="hd"><span class="label">События</span></div>
    <Events limit={theme.profile === 'tablet' ? 4 : 3} />
  </section>
</div>

<style>
  .vt { display: grid; grid-template-columns: minmax(0, 1fr); gap: 10px; }
  .vt.tablet { grid-template-columns: minmax(0, 1fr) minmax(0, 1.6fr); }
  section { padding: 14px 16px; border-radius: var(--r-xl, 24px); background: var(--surface); border: 1px solid var(--border); min-width: 0; }
  .plain section { padding: 12px 0 0; border: 0; border-top: 1px solid var(--text); border-radius: 0; background: none; }
  .hd { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
  .live { display: inline-flex; align-items: center; gap: 6px; font-size: 12px; color: var(--muted); }
  .live i { width: 7px; height: 7px; border-radius: 50%; background: var(--ok); animation: blink 2s infinite; }
  @keyframes blink { 50% { opacity: .3; } }
  .v { display: flex; align-items: baseline; gap: 6px; } .v b { font: var(--display-weight, 300) 40px/1 var(--font-num, var(--font-display)); letter-spacing: -.03em; } .v span { color: var(--muted); font-size: 14px; }
  svg { display: block; width: 100%; height: 56px; margin-top: 8px; }
  .a { fill: color-mix(in srgb, var(--accent) 16%, transparent); } .l { fill: none; stroke: var(--accent); stroke-width: 1.5; vector-effect: non-scaling-stroke; }
  @media (prefers-reduced-motion: reduce) { .live i { animation: none; } }
</style>
