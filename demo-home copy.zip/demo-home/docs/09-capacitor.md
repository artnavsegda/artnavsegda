# 09. Сборка в телефон (Capacitor 8)

Цель — подержать прототип в руке: тот же клиент из `dist/`, обёрнутый в нативное приложение.
Симулятор дома работает внутри приложения, сеть нужна только для шрифтов Google Fonts.

## Что уже сделано

- `capacitor.config.ts`: `appId: dev.demohome.app` (заглушка), `appName: Демо-дом`, `webDir: dist`.
- Платформы сгенерированы и лежат в репозитории: `android/` (Gradle), `ios/` (Xcode, Swift Package Manager, без CocoaPods).
- Веб-сборка копируется в `android/app/src/main/assets/public` и `ios/App/App/public`. Обе папки в `.gitignore` платформ,
  их создаёт `cap sync`.
- `src/client/native.ts` — мостик к телефону. В браузере и в артефакте ничего не делает:
  - `tap()` — лёгкая вибрация (`@capacitor/haptics`): переключатели (`Toggle`) и любой переход `go()`;
  - `systemBars(mode)` — цвет значков статус-бара под тему (`SystemBars` из `@capacitor/core`), вызывается в `applyTheme()`.
- Края экрана: `viewport-fit=cover` в `index.html` + `SystemBars.insetsHandling: 'css'`. Вёрстка уже везде берёт отступы
  из `env(safe-area-inset-*)`, на Android с Chromium < 140 Capacitor подставляет отступы сам.
- iOS `Info.plist`: подписи доступа к камере и фото — для загрузки аватара в профиле.

## Команды

```
npm install
npm run android        # сборка → cap sync android → открыть Android Studio
npm run ios            # сборка → cap sync ios → открыть Xcode (только macOS)
npm run android:run    # сразу на подключённый телефон/эмулятор (нужен adb)
npm run ios:run        # сразу на iPhone/симулятор
npm run cap:sync       # пересобрать веб и разложить в обе платформы
```

## Требования (Capacitor 8)

- Node 22+ (проверено на 22.23).
- Android: Android Studio последней ветки, JDK 21, Android SDK 36; minSdk 24.
  Телефон — режим разработчика + отладка по USB. Первый запуск Gradle скачивает зависимости долго.
- iOS: свежий Xcode (Capacitor 8 рассчитан на Xcode 26), iOS 15+. Подпись: Xcode → App → Signing & Capabilities → своя команда (Personal Team подойдёт
  для установки на свой iPhone на 7 дней).

## Что проверить в руке

- Нижняя навигация и отступ под «домашней» полоской / жестовой панелью Android.
- Тактильный отклик переключателей и вкладок — не слишком ли часто.
- 3D-диорама на «Доме» и плитки устройств (WebGL) — плавность на конкретном телефоне.
- Профиль → «Загрузить фото» (камера/галерея), тема Авто/Светлая/Тёмная — меняется ли цвет статус-бара.
- Пульт «Демо» остаётся и в приложении — им переключаются тренд, время суток и объект.

## Дальше

- Иконка и заставка: `npx @capacitor/assets generate` из `resources/icon.png` и `resources/splash.png` (пакет не установлен).
- Настоящий `appId`/название — вместе с названием продукта.
- Стенная панель: режим киоска на Android (lock task), старт со страницы своей комнаты.
- Подключение к контроллеру: вместо `HouseSim` — WebSocket-транспорт (`src/client/store.svelte.ts`, одна строка),
  для локальной сети на Android может понадобиться `android:usesCleartextTraffic` или https на контроллере.
