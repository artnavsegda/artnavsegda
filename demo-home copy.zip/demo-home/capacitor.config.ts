import type { CapacitorConfig } from '@capacitor/cli';

// Нативная обёртка для проверки «в руке»: тот же клиент (dist/), что и в браузере.
// appId — заглушка демо-стенда; настоящий идентификатор появится вместе с названием продукта.
const config: CapacitorConfig = {
  appId: 'dev.demohome.app',
  appName: 'Демо-дом',
  webDir: 'dist',
  backgroundColor: '#0E0F12',
  plugins: {
    // Android: страница рисуется под системными панелями, отступы берём из env(safe-area-inset-*) — как в Safari на iPhone
    SystemBars: { insetsHandling: 'css', initialViewportFitValueHint: 'cover' }
  }
};

export default config;
