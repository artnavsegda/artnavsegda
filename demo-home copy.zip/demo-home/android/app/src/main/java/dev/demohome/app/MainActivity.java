package dev.demohome.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
